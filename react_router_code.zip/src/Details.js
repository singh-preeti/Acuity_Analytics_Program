import React, { Component } from "react";

class Details extends Component {

  constructor() {
    super();
    this.state = {
      user: {}
    };
  }

  componentDidMount() {
    const data = JSON.parse(localStorage.getItem("userData"));
    this.setState({ user: data });
  }

  render() {
    const u = this.state.user;

    return (
      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <h2>User Details</h2>

        <p>Name: {u?.name}</p>
        <p>Email: {u?.email}</p>
        <p>Phone: {u?.phone}</p>
        <p>Account Type: {u?.accountType}</p>
      </div>
    );
  }
}

export default Details;