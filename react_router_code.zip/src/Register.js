import React, { Component } from "react";

class Register extends Component {

  constructor() {
    super();

    this.state = {
      name: "",
      email: "",
      phone: "",
      accountType: "Savings",
      password: ""
    };
  }

  handleChange = (e) => {
    this.setState({
      [e.target.id]: e.target.value
    });
  };

  handleSubmit = (e) => {
    e.preventDefault();

    // navigate to details page with data
    window.location.href = "/details";
    localStorage.setItem("userData", JSON.stringify(this.state));
  };

  render() {
    return (
      <div style={styles.container}>
        <h2>Register</h2>

        <form onSubmit={this.handleSubmit}>
          <input type="text" id="name" placeholder="Name" onChange={this.handleChange} />
          <input type="email" id="email" placeholder="Email" onChange={this.handleChange} />
          <input type="text" id="phone" placeholder="Phone" onChange={this.handleChange} />

          <select id="accountType" onChange={this.handleChange}>
            <option>Savings</option>
            <option>Current</option>
          </select>

          <input type="password" id="password" placeholder="Password" onChange={this.handleChange} />

          <button type="submit">Submit</button>
        </form>
      </div>
    );
  }
}

const styles = {
  container: {
    width: "300px",
    margin: "auto",
    marginTop: "50px"
  }
};

export default Register;