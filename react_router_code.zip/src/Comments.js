import React from 'react';

const Comments = () => {
    return (
        <div>
             Hello I am child component!
        </div>
    );
};
export default Comments;