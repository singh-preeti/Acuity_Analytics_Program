import React, { Component } from "react";

class Home extends Component {
  render() {
    return <h2 style={{ textAlign: "center" }}>Welcome to Bank App</h2>;
  }
}

export default Home;