import React, { Component } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./Home";
import Register from "./Register";
import Details from "./Details";

class App extends Component {
  render() {
    return (
      <Router>
        <div style={styles.nav}>
          <Link to="/">Home</Link> |{" "}
          <Link to="/registe">Register</Link>
          <Link to="/details">Details</Link>
        </div>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/registe" element={<Register />} />
          <Route path="/details" element={<Details />} />
        </Routes>
      </Router>
    );
  }
}

const styles = {
  nav: {
    padding: "10px",
    background: "#eee"
  }
};

export default App;