import React from "react";

const UserCard = () => {
    return(
        <div>
            
            Hello I am User Card Component!
            <table>
                <tr>
                    <th>id</th>
                    <th>name</th>
                </tr>
                <tr>
                    <td>101</td>
                    <td>Anurag</td>
                </tr>
            </table>
        </div>
    )
}
export default UserCard;