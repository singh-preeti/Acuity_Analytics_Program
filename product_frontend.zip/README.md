# Product Management App - Beginner's Guide

## 📚 What is this app?
This is a simple web application where you can:
- ✅ Add new products
- ✅ View all products in a table
- ✅ Edit existing products
- ✅ Delete products

## 🏗️ Technology Stack

### Frontend (What user sees)
- **React** - JavaScript library to build user interface
- **Axios** - Library to make HTTP requests to backend
- **Bootstrap** - CSS framework for styling

### Backend (Server that stores data)
- **Spring Boot** - Java framework to create REST API
- **H2 Database** - In-memory database (data resets when server stops)

## 📁 Project Structure

```
E-Commerce/
├── src/                          (React Frontend)
│   ├── App.jsx                   (Main component - ALL code is here!)
│   └── index.jsx                 (Entry point - loads App.jsx)
│
└── springboot-backend/           (Spring Boot Backend)
    └── src/main/java/com/product/
        ├── ProductApplication.java    (Starts the server)
        ├── Product.java               (Product data structure)
        ├── ProductRepository.java     (Database operations)
        ├── ProductService.java        (Business logic)
        └── ProductController.java     (API endpoints)
```

## 🔄 How it Works (Step by Step)

### 1️⃣ When you open the app:
- React calls `loadProducts()` function
- This sends GET request to: `http://localhost:8080/product/get`
- Spring Boot fetches all products from database
- React displays them in a table

### 2️⃣ When you ADD a product:
- You fill the form and click "Add"
- React sends POST request to: `http://localhost:8080/product/add`
- Spring Boot saves it to database
- React refreshes the product list

### 3️⃣ When you EDIT a product:
- You click "Edit" button
- Form fills with that product's data
- You change values and click "Update"
- React sends PUT request to: `http://localhost:8080/product/update`
- Spring Boot updates the database
- React refreshes the product list

### 4️⃣ When you DELETE a product:
- You click "Delete" button
- Browser asks "Are you sure?"
- React sends DELETE request to: `http://localhost:8080/product/deletebyid/{id}`
- Spring Boot removes it from database
- React refreshes the product list

## 🚀 How to Run

### Step 1: Start Backend (Spring Boot)
```bash
cd springboot-backend
mvn spring-boot:run
```
Backend will run on: `http://localhost:8080`

### Step 2: Start Frontend (React)
Open a new terminal:
```bash
npm run dev
```
Frontend will run on: `http://localhost:5173` or `http://localhost:5174`

### Step 3: Open Browser
Go to: `http://localhost:5173`

## 🧠 Key Concepts for Beginners

### React Hooks Used:

1. **useState** - Stores data in component
   ```javascript
   const [products, setProducts] = useState([])
   // products = current value
   // setProducts = function to update value
   ```

2. **useEffect** - Runs code when component loads
   ```javascript
   useEffect(function() {
     loadProducts()  // Fetch products on page load
   }, [])
   ```

### Axios HTTP Methods:

| Method | Purpose | Example |
|--------|---------|---------|
| GET | Fetch data | `axios.get(url)` |
| POST | Add new data | `axios.post(url, data)` |
| PUT | Update data | `axios.put(url, data)` |
| DELETE | Remove data | `axios.delete(url)` |

### Bootstrap Classes Used:

- `container` - Centers content with padding
- `card` - Box with border and shadow
- `btn btn-success` - Green button
- `btn btn-warning` - Yellow button
- `btn btn-danger` - Red button
- `table table-striped` - Table with alternating row colors
- `form-control` - Styled input field

## 🎯 Learning Path

1. **First** - Understand the UI (what you see in browser)
2. **Second** - Read `App.jsx` from top to bottom
3. **Third** - Understand each function (loadProducts, saveProduct, etc.)
4. **Fourth** - See how form inputs are connected to state variables
5. **Fifth** - Understand how axios makes API calls
6. **Sixth** - Look at Spring Boot backend code

## 🐛 Common Issues

### CORS Error
**Problem:** "Access blocked by CORS policy"
**Solution:** Make sure `ProductController.java` has:
```java
@CrossOrigin(origins = {"http://localhost:5173", "http://localhost:5174", "http://localhost:5175"})
```

### Connection Refused
**Problem:** "Network Error" or "ERR_CONNECTION_REFUSED"
**Solution:** Make sure Spring Boot backend is running on port 8080

### Port Already in Use
**Problem:** "Port 8080 is already in use"
**Solution:** Stop other Java applications or change port in `application.properties`

## 📖 Next Steps to Learn More

1. Add more fields (category, image URL, stock quantity)
2. Add search/filter functionality
3. Add pagination (show 10 products per page)
4. Connect to real database (MySQL/PostgreSQL)
5. Add user authentication (login/logout)
6. Deploy to cloud (AWS, Heroku, Netlify)

## 💡 Tips for Beginners

- Read code comments carefully
- Use `console.log()` to debug
- Open browser DevTools (F12) to see network requests
- Change one thing at a time and test
- Don't worry about making mistakes - that's how you learn!

---

**Happy Coding! 🎉**
