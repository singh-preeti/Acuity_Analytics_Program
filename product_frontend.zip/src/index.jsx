import React from 'react'
import ReactDOM from 'react-dom/client'

// Importing Bootstrap CSS for styling
// This single import gives us access to all Bootstrap classes
import 'bootstrap/dist/css/bootstrap.min.css'

import App from './App'

ReactDOM.createRoot(document.getElementById('root')).render(<App />)
