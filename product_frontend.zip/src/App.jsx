import { useState, useEffect } from 'react'
import axios from 'axios'

const URL = 'http://localhost:8080/product'

function App() {

  const [products, setProducts] = useState([])
  const [productName, setProductName] = useState('')
  const [productPrice, setProductPrice] = useState('')
  const [productDescription, setProductDescription] = useState('')

  useEffect(function () {
    loadProducts()
  }, [])

  function loadProducts() {
    axios.get(URL + '/get').then(function (response) {
      setProducts(response.data)
    })
  }

  function saveProduct(event) {
    event.preventDefault()
    const product = { name: productName, price: productPrice, description: productDescription }
    axios.post(URL + '/add', product).then(function () {
      setProductName('')
      setProductPrice('')
      setProductDescription('')
      loadProducts()
    })
  }

  return (
    <div>
      <nav className="navbar navbar-dark bg-primary">
        <div className="container">
          <span className="navbar-brand"> Product Management</span>
        </div>
      </nav>

      <div className="container mt-4">

        <div className="card mb-4">
          <div className="card-header bg-success text-white">
            <h5> Add Product</h5>
          </div>
          <div className="card-body">
            <form onSubmit={saveProduct}>
              <div className="mb-3">
                <label className="form-label">Product Name</label>
                <input type="text" className="form-control" value={productName}
                  onChange=
                  {function (e) 
                  { setProductName(e.target.value) }} placeholder="Enter product name" required />
              </div>
              <div className="mb-3">
                <label className="form-label">Price</label>
                <input type="number" className="form-control" value={productPrice}
                  onChange={function (e) { setProductPrice(e.target.value) }} placeholder="Enter price" required />
              </div>
              <div className="mb-3">
                <label className="form-label">Description</label>
                <input type="text" className="form-control" value={productDescription}
                  onChange={function (e) { setProductDescription(e.target.value) }} placeholder="Enter description" required />
              </div>
              <button type="submit" className="btn btn-success">Add</button>
            </form>
          </div>
        </div>

        <div className="card">
          <div className="card-header bg-primary text-white">
            <h5> Product List ({products.length})</h5>
          </div>
          <div className="card-body p-0">
            <table className="table table-striped mb-0">
              <thead className="table-dark">
                <tr>
                  <th>ID</th><th>Name</th><th>Price</th><th>Description</th>
                </tr>
              </thead>
              <tbody>
                {products.map(function (product) {
                  return (
                    <tr key={product.id}>
                      <td>{product.id}</td>
                      <td>{product.name}</td>
                      <td>₹{product.price}</td>
                      <td>{product.description}</td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </div>
  )
}

export default App
