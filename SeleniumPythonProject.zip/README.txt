Selenium Python Project (Pytest + POM)

Setup:
1. Install Python (3.9+ recommended)
2. pip install -r requirements.txt

Run:
pytest -v

Features:
- Page Object Model
- WebDriverManager (auto driver setup)
- Explicit waits (dashboard)
- Ready for PyCharm
