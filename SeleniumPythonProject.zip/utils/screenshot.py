def take_screenshot(driver, name):
    driver.save_screenshot(f"{name}.png")
