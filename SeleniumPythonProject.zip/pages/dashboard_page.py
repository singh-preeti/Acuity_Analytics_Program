from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class DashboardPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)

    title = (By.CLASS_NAME, "title")
    menu = (By.ID, "react-burger-menu-btn")
    logout = (By.ID, "logout_sidebar_link")

    def get_title(self):
        return self.wait.until(EC.visibility_of_element_located(self.title)).text

    def logout_app(self):
        self.driver.find_element(*self.menu).click()
        self.wait.until(EC.element_to_be_clickable(self.logout)).click()
