from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage

def test_valid_login(setup):
    driver = setup
    login = LoginPage(driver)
    login.login("standard_user", "secret_sauce")

    dashboard = DashboardPage(driver)
    assert dashboard.get_title() == "Products"

def test_invalid_login(setup):
    driver = setup
    login = LoginPage(driver)
    login.login("wrong", "wrong")

    assert "do not match" in login.get_error()
