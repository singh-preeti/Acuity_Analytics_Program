from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage

def test_logout(setup):
    driver = setup
    login = LoginPage(driver)
    login.login("standard_user", "secret_sauce")

    dashboard = DashboardPage(driver)
    dashboard.logout_app()

    assert "saucedemo" in driver.current_url
