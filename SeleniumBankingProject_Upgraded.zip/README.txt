Upgraded Selenium Project

Features:
- WebDriverManager (no driver setup)
- Explicit Waits (WaitUtils)
- Screenshot on failure
- TestNG suite execution

Run:
1. Import as Maven project in IntelliJ
2. Run testng.xml

Note:
Screenshots saved in /screenshots folder.
