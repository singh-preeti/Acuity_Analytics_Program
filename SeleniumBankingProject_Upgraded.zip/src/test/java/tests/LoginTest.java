package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.DashboardPage;
import utils.ScreenshotUtils;

public class LoginTest extends BaseTest {

    @Test
    public void validLogin() {
        try {
            LoginPage login = new LoginPage(driver);
            login.login("standard_user", "secret_sauce");

            DashboardPage dashboard = new DashboardPage(driver);
            Assert.assertEquals(dashboard.getTitle(), "Products");
        } catch (Exception e) {
            ScreenshotUtils.capture(driver, "validLogin");
            throw e;
        }
    }

    @Test
    public void invalidLogin() {
        try {
            LoginPage login = new LoginPage(driver);
            login.login("wrong", "wrong");

            Assert.assertTrue(login.getErrorMessage().contains("do not match"));
        } catch (Exception e) {
            ScreenshotUtils.capture(driver, "invalidLogin");
            throw e;
        }
    }
}
