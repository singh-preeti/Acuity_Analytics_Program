package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;
import pages.DashboardPage;
import utils.ScreenshotUtils;

public class DashboardTest extends BaseTest {

    @Test
    public void logoutTest() {
        try {
            LoginPage login = new LoginPage(driver);
            login.login("standard_user", "secret_sauce");

            DashboardPage dashboard = new DashboardPage(driver);
            dashboard.logout();

            Assert.assertTrue(driver.getCurrentUrl().contains("saucedemo"));
        } catch (Exception e) {
            ScreenshotUtils.capture(driver, "logoutTest");
            throw e;
        }
    }
}
