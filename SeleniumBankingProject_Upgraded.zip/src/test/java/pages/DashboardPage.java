package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import utils.WaitUtils;

public class DashboardPage {
    WebDriver driver;
    WaitUtils wait;

    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        wait = new WaitUtils(driver);
    }

    By title = By.className("title");
    By menu = By.id("react-burger-menu-btn");
    By logout = By.id("logout_sidebar_link");

    public String getTitle() {
        wait.waitForVisibility(title);
        return driver.findElement(title).getText();
    }

    public void logout() {
        driver.findElement(menu).click();
        wait.waitForClickable(logout);
        driver.findElement(logout).click();
    }
}
