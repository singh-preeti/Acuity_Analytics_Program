package com.product;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/product")
@CrossOrigin(origins = { "http://localhost:5173"})
public class ProductController {
   
    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @GetMapping("/get")
    public List<Product> getAll() {
        return service.getAll();
    }

    @PostMapping("/add")
    public Product add(@RequestBody Product product) {
        return service.add(product);
    }

    @PutMapping("/update")
    public Product update(@RequestBody Product product) {
        return service.update(product);
    }

    @DeleteMapping("/deletebyid/{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id) {
        service.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
